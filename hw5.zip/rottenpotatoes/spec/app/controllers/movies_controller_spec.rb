# require 'movie'
require 'rails_helper'

describe MoviesController do
  it "test " do
    expect true==true
  end
end